const loginURL = 'http://localhost:3030/users/login';

const sectionElement = document.getElementById('login-view');
const loginForm = sectionElement.querySelector('form');

export default function loginPage(){
    sectionElement.style.display = 'inline-block';
}

loginForm.addEventListener('submit', onSubmitLogin);

function onSubmitLogin(event){
    event.preventDefault();

    const emailInput = event.target.querySelector("#login input[type='text']");
    const passwordInput = event.target.querySelector("#login input[type='password']");
    const notification = event.target.querySelector('.notification');

    
    const email = emailInput.value;
    const password = passwordInput.value;

   if(email === '' || password === ''){
        notification.textContent = 'Please fill in the fields';
        return;
   }
    
   fetch(loginURL, {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify({
        email: email,
        password: password,
    }),
   })
   .then(res => res.json())
   .then(data => {
        if(data.code >= 400){
            notification.textContent = 'Username or password is incorrect!';
            return;
        }

        localStorage.setItem('accessToken', data.accessToken);
        localStorage.setItem('email', data.email);
        localStorage.setItem('_id', data._id);

        location.reload();
   })
   .catch(err => {
        notification.textContent = 'Username or password is incorrect!';
        alert(err.message);
    })
    
}